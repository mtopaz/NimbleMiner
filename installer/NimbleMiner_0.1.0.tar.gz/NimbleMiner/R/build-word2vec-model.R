library(tm)
library(stringi)
TextPreprocess <- function(fileName_in = 'train.txt',fileName_out = 'train1.txt', length_of_text_chunk=5e7, fl_remove_numbers = TRUE, fl_to_lower = TRUE){

  if(!file.exists(fileName_in)) {
    cat('Error:The file with text ',fileName_in,' is not found!')
    return('')
  }

  file_size = file.info(fileName_in)$size
  in.file = file(fileName_in, "r")


  i<-1
  #clear output file
  close( file( fileName_out, open="w" ) )
  curr_chunk <- readChar(in.file,length_of_text_chunk)
  length_of_curr_chunk <- nchar(curr_chunk)
  while( length_of_curr_chunk >0  ) {

    print(paste("Preprocessing ", i," part..."))


    if(length_of_curr_chunk>0){

      #includes whole last word to the current chunk
      length_end_of_word = 1
      while (length_end_of_word>0 & grepl("\\w",substring(curr_chunk,length_of_curr_chunk,length_of_curr_chunk))) {

        end_of_word <- readChar(in.file,1)
        length_end_of_word <- ifelse(length(end_of_word)==0,0,nchar(end_of_word))
        curr_chunk <- paste0(curr_chunk,end_of_word)
        length_of_curr_chunk = length_of_curr_chunk+1

      }

      cat("removing the punctuation...")
      curr_chunk=removePunctuation(curr_chunk)
      if(fl_to_lower){
        cat("converting to lower case...")
        curr_chunk=stri_trans_tolower(curr_chunk)
      }

      if (fl_remove_numbers) {
        cat("removing the numbers...")
        curr_chunk = removeNumbers(curr_chunk)
      }

      # if(Encoding(curr_chunk)!="UTF-8")  Encoding(curr_chunk)<-"UTF-8"
      out.file = file(fileName_out, "at")
      writeChar(curr_chunk,out.file,nchar(curr_chunk))
      close( out.file )
      i=i+1
      curr_chunk <- readChar(in.file,length_of_text_chunk)
      length_of_curr_chunk <- ifelse(length(curr_chunk)==0,0,nchar(curr_chunk))
    }
  }
  cat("Preprocessing completed.")
  close( in.file )

}
