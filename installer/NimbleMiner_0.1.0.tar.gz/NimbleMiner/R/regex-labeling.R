library(tm)
library(stringi)
assigneLabels <- function(filename, df_simclins, categories_list, app_dir, df_negations = NULL, df_exceptions = NULL, utf8_language = FALSE){

  # create pattern for regex from simclins
  # divide pattern by substrings from 50000 chars because of the limit by length for the pattern string
  pattern_limit <- 5000
  pattern_list = c()
  pattern_str <- ""

  df_simclins_for_search <- df_simclins[!duplicated(df_simclins$Simclins) & (df_simclins$Category %in% categories_list), ]

  if(nrow(df_simclins_for_search)>0)
    for (i in 1:nrow(df_simclins_for_search)){
      df_simclins_for_search$Simclins[i]<- gsub("\\+","",df_simclins_for_search$Simclins[i])
      df_simclins_for_search$Simclins[i]<- gsub("_"," ",df_simclins_for_search$Simclins[i])
      pattern_str <- paste0(pattern_str,"|",df_simclins_for_search$Simclins[i],"")
      #if the length of current substring is limit over - create the new substring
      if(nchar(pattern_str)>=pattern_limit-50){
        pattern_str <- substr(pattern_str,2,nchar(pattern_str))
        pattern_str <- paste0("\\b(",pattern_str,")\\b")
        pattern_list <- c(pattern_list,pattern_str)
        pattern_str <- ""

      }
    }

  if (nchar(pattern_str)>0) {
    pattern_str <- substr(pattern_str,2,nchar(pattern_str))
    pattern_str <- paste0("\\b(",pattern_str,")\\b")
    pattern_list <- c(pattern_list,pattern_str)
  }

  if(utf8_language){
    pattern_list<- enc2utf8(pattern_list)
  }

  cat("Reading text file...")

  df_corpus_to_label <- read.csv(filename,header = TRUE, stringsAsFactors=FALSE,comment.char = "", colClasses = "character",fileEncoding = "UTF-8")

  notes_column_index <- getColumnToUpload(df_corpus_to_label,"Note",c("character","factor"))

  if(notes_column_index==0){
    return(list("error_msg" = "The column \'Note\' or any character/factor column not found in the specified the file. Please, upload the file with column \'Note\'."))
  }

  colnames(df_corpus_to_label)[notes_column_index]<-'Note'


  if(input$unit_type_to_label==2){
    colnames(df_corpus_to_label)[notes_column_index]<-'Source_note'
    df_allNotes <- data.frame(matrix(ncol = ncol(df_corpus_to_label)+1, nrow = 0))
    colnames(df_allNotes)<-c(colnames(df_corpus_to_label),'Note')
    for(indx_note in 1:nrow(df_corpus_to_label)){
      paragraphs_of_curr_note <-unlist(tokenize_paragraphs(df_corpus_to_label[indx_note,'Source_note']))
      rows_of_curr_note <- rep(df_corpus_to_label[indx_note,], each =  length(paragraphs_of_curr_note))
      merged_rows_of_curr_note <- cbind(rows_of_curr_note,Note = paragraphs_of_curr_note)
      df_allNotes <- rbind(df_allNotes,merged_rows_of_curr_note)
    }
    info_to_user<-paste0(nrow(df_allNotes)," paragraphs from ",nrow(df_corpus_to_label)," notes")
  } else if(input$unit_type_to_label==3){
    colnames(df_corpus_to_label)[notes_column_index]<-'Source_note'
    df_allNotes <- data.frame(matrix(ncol = ncol(df_corpus_to_label)+1, nrow = 0))
    colnames(df_allNotes)<-c(colnames(df_corpus_to_label),'Note')
    for(indx_note in 1:nrow(df_corpus_to_label)){
      sentences_of_curr_note <-unlist(tokenize_sentences(df_corpus_to_label[indx_note,'Source_note']))
      rows_of_curr_note <- rep(df_corpus_to_label[indx_note,], each =  length(sentences_of_curr_note))
      merged_rows_of_curr_note <- cbind(rows_of_curr_note,Note = sentences_of_curr_note)
      df_allNotes <- rbind(df_allNotes,merged_rows_of_curr_note)
    }
    info_to_user<-paste0(nrow(df_allNotes)," sentences from ",nrow(df_corpus_to_label)," notes")
  } else {
    df_allNotes <- df_corpus_to_label
    info_to_user<-paste0(nrow(df_allNotes)," notes")
  }

  rm(df_corpus_to_label)

  # pre-processing of data for labeling
  df_allNotes$Note <- tolower(df_allNotes$Note)
  # df_allNotes$Note=gsub("[[:punct:]]", " ", df_allNotes$Note) - follow to errors in Hebrew corpus
  df_allNotes$Note = tm::removePunctuation(df_allNotes$Note,preserve_intra_word_contractions = FALSE,preserve_intra_word_dashes = FALSE,ucp = TRUE)

  df_allNotes$NimbleMiner_ID <- seq.int(nrow(df_allNotes))

  # labeling all notes by regex with simclins
  df_allNotes$Label <- FALSE
  if(length(pattern_list)>0 & nrow(df_allNotes)>0)
    for(i in 1:length(pattern_list)){
      cat(paste0("Filtering positive items from ",info_to_user," by ",i,"/",length(pattern_list)," part of simclins list from ",Sys.time()))
      start_time <- Sys.time()
      new_values <- grepl(pattern_list[i], df_allNotes$Note, ignore.case = TRUE)
      df_allNotes$Label <- ifelse(new_values == TRUE, TRUE,df_allNotes$Label)
      cat(paste0('Duration: ', round((difftime(Sys.time(),start_time,units = "min")),2)))

    }

  write.csv(df_allNotes, file = paste0(app_dir,"raw_labeled_data_utf8.csv"), fileEncoding = "UTF-8")


  fileName_all_labeled_data <- paste0(app_dir,"labeled-data-",format(Sys.time(), "%Y-%m-%d_%H-%M"),".csv")
  write.csv(df_allNotes[df_allNotes[,'Label']==FALSE,], file = paste0(app_dir,"negative_labeled_data.csv"), fileEncoding = "UTF-8")
  write.csv(df_allNotes[df_allNotes[,'Label']==FALSE,], file = fileName_all_labeled_data, na = "", fileEncoding = "UTF-8")

  orignal_source_colnames <- colnames(df_allNotes)

  df_positiveLabels <- data.frame(df_allNotes[df_allNotes[,'Label']==TRUE,],stringsAsFactors=FALSE)
  if (nrow(df_positiveLabels)>0)
    df_positiveLabels$Simclins <-""
  else df_positiveLabels$Simclins <-character(0)

  total_notes <- nrow(df_allNotes)
  total_negated_notes <-0

  rm(df_allNotes)

  # get pattern for pre-negations search by categories

  pattern_pre_negations_list<-vector("list",length(categories_list)+1)
  names(pattern_pre_negations_list)<-c("General",categories_list)

  pattern_pre_negations <- ""
  df_pre_negations <-data.table(df_negations[df_negations$Type=='before',])

  # get pattern for general negations
  df_pre_negations_curr_cat <- df_pre_negations[df_pre_negations$Category=="General",]
  if(nrow(df_pre_negations_curr_cat)>0){
    list_pre_negations <- ""
    for(neg_indx in 1:nrow(df_pre_negations_curr_cat))
      list_pre_negations <- paste0(list_pre_negations,"|",df_pre_negations_curr_cat[neg_indx,"Negation"])
    if(nchar(list_pre_negations)>0) {
      list_pre_negations <- substring(list_pre_negations,2,nchar(list_pre_negations))
      pattern_pre_negations <- gsub("_"," ",list_pre_negations)
      if(utf8_language) pattern_pre_negations<-enc2utf8(pattern_pre_negations)
      pattern_pre_negations <- paste0("(\\b(",pattern_pre_negations,")\\b)")
    }
    pattern_pre_negations_list[['General']]<-pattern_pre_negations
  }

  # get patterns for all categories
  if(length(categories_list)>0)
    for(i in 1:length(categories_list)){
      pattern_pre_negations <- ""
      list_pre_negations <- ""
      df_pre_negations_curr_cat <- df_pre_negations[df_pre_negations$Category==categories_list[i],]

      if(nrow(df_pre_negations_curr_cat)>0){
        for(neg_indx in 1:nrow(df_pre_negations_curr_cat))
          list_pre_negations <- paste0(list_pre_negations,"|",df_pre_negations_curr_cat[neg_indx,"Negation"])
        # pattern_pre_negations <- paste0("(\\b(",list_pre_negations,gsub("_"," ",list_pre_negations),")\\b)")
        if(nchar(list_pre_negations)>0) {
          list_pre_negations <- substring(list_pre_negations,2,nchar(list_pre_negations))
          pattern_pre_negations <- gsub("_"," ",list_pre_negations)
          if(utf8_language) pattern_pre_negations<-enc2utf8(pattern_pre_negations)
          pattern_pre_negations <- paste0("(\\b(",pattern_pre_negations,")\\b)")
        }
        pattern_pre_negations_list[[categories_list[i]]] <- pattern_pre_negations
      }
    }
  rm(df_pre_negations)

  pattern_post_negations <- ""
  df_post_negations <-data.table(df_negations[df_negations$Type=='after',])

  pattern_post_negations_list<-vector("list",length(categories_list)+1)
  names(pattern_post_negations_list)<-c("General",categories_list)

  # get pattern for general negations
  df_post_negations_curr_cat <- df_post_negations[df_post_negations$Category=="General",]
  if(nrow(df_post_negations_curr_cat)>0){
    list_post_negations <- ""
    for(neg_indx in 1:nrow(df_post_negations_curr_cat))
      list_post_negations <- paste0(list_post_negations,"|",df_post_negations_curr_cat[neg_indx,"Negation"])
    if(nchar(list_post_negations)>0) {
      list_post_negations <- substring(list_post_negations,2,nchar(list_post_negations))
      pattern_post_negations <- paste0(list_post_negations,"|",gsub("_"," ",list_post_negations))
      if(utf8_language) pattern_post_negations<-enc2utf8(pattern_post_negations)
      pattern_post_negations <- paste0("(\\b(",pattern_post_negations,")\\b)")
    }
    pattern_post_negations_list[['General']]<-pattern_post_negations
  }

  # get patterns for specific negations for categories
  if(length(categories_list)>0)
    for(i in 1:length(categories_list)){
      pattern_post_negations <- ""
      list_post_negations <- ""
      df_post_negations_curr_cat <- df_post_negations[df_post_negations$Category==categories_list[i],]

      if(nrow(df_post_negations_curr_cat)>0){
        for(neg_indx in 1:nrow(df_post_negations_curr_cat))
          list_post_negations <- paste0(list_post_negations,"|",df_post_negations_curr_cat[neg_indx,"Negation"])
        # pattern_post_negations <- paste0("(\\b(",list_post_negations,gsub("_"," ",list_post_negations),")\\b)")
        if(nchar(list_post_negations)>0) {
          list_post_negations <- substring(list_post_negations,2,nchar(list_post_negations))
          pattern_post_negations <- paste0(list_post_negations,"|",gsub("_"," ",list_post_negations))
          if(utf8_language) pattern_post_negations<-enc2utf8(pattern_post_negations)
          pattern_post_negations <- paste0("(\\b(",pattern_post_negations,')\\b)')
        }
        pattern_post_negations_list[[categories_list[i]]] <- pattern_post_negations
      }
    }
  rm(df_post_negations)


  df_false_positiveLabels <- vector(mode = "logical", length = 0)
  df_irrelevant_positiveLabels <- vector(mode = "logical", length = 0)
  categories_cols_names <-"Simclins"

  if(nrow(df_positiveLabels)>0){

    if(length(categories_list)>0)
      for (cat_indx in 1:length(categories_list)){
        category_column_simclins_name <- paste0(categories_list[cat_indx],' (simclins)')
        category_column_simclins_count_name <- paste0(categories_list[cat_indx],' (# of simclins)')
        df_positiveLabels[,category_column_simclins_name]=""
        df_positiveLabels[,category_column_simclins_count_name]=0
        categories_cols_names <- paste0(categories_cols_names,",",category_column_simclins_name,",",category_column_simclins_count_name)
      }


    if (nrow(df_positiveLabels)>1)
      pb <- txtProgressBar(1,nrow(df_positiveLabels), style = 3)

    for(i in 1:nrow(df_positiveLabels)){

      curr_note = df_positiveLabels[i,"Note"]

      if(utf8_language) curr_note <- enc2utf8(curr_note)

      noteOfLabel = FALSE

      all_simclins_of_note <-c()
      curr_note_negations <- c()
      curr_note_irrelevant_terms <- c()

      tags_simclins <- data.frame(matrix(ncol = 3, nrow = 0))
      colnames(tags_simclins)<-c('word','start','end')
      tags_negated_simclins <- data.frame(matrix(ncol = 3, nrow = 0))
      colnames(tags_negated_simclins)<-c('word','start','end')
      tags_irrelevant_simclins <- data.frame(matrix(ncol = 3, nrow = 0))
      colnames(tags_negated_simclins)<-c('word','start','end')

      #check all simclins for negation
      #get simclins
      for(pattern_list_indx in 1:length(pattern_list)){

        list_simclins = stri_locate_all(curr_note, regex = pattern_list[pattern_list_indx], opts_regex=stri_opts_regex(case_insensitive=TRUE))
        prev_pos_end = 0

        #search simclins in note
        for (j in 1:nrow(list_simclins[[1]])){

          pos_start = list_simclins[[1]][j,'start']
          pos_end   = list_simclins[[1]][j,'end']

          if(!is.na(pos_start) & !is.na(pos_end)) {

            isSimclinIrrelevant = FALSE
            isSimclinNegated = FALSE

            curr_simclin = substring(curr_note,pos_start,pos_end)

            curr_simclin_categories <- df_simclins_for_search[df_simclins_for_search$Simclin==stri_trans_tolower(curr_simclin),'Category']

            #simclin` relevance check

            #there are irrelevant expressions for current simclin

            df_irrelevant_terms_of_simclin_cat <- df_irrelevant_terms[df_irrelevant_terms$Category %in% curr_simclin_categories,'Similar_term']

            if(length(grep(curr_simclin,df_irrelevant_terms_of_simclin_cat,ignore.case = TRUE))!=0){
              df_irrelevant_simclins <-df_irrelevant_terms_of_simclin_cat[grepl(curr_simclin,df_irrelevant_terms_of_simclin_cat,ignore.case = TRUE)]

              pattern_irrelevant_terms = paste(df_irrelevant_simclins, collapse = '|', sep="")
              pattern_irrelevant_terms = paste(pattern_irrelevant_terms,"|",gsub("_"," ",pattern_irrelevant_terms), sep="")

              if(utf8_language) pattern_irrelevant_terms <- enc2utf8(pattern_irrelevant_terms)
              irr_expressions_in_note = stri_locate_all(curr_note, regex =  paste("(",pattern_irrelevant_terms,")", sep=""), opts_regex=stri_opts_regex(case_insensitive=TRUE))

              #check every irrelevant expression for current simclin
              for (i_irr_expr in 1:nrow(irr_expressions_in_note[[1]])){
                start_pos_expression_in_note = irr_expressions_in_note[[1]][i_irr_expr,'start']
                end_pos_expression_in_note = irr_expressions_in_note[[1]][i_irr_expr,'end']
                if(!is.na(start_pos_expression_in_note)){
                  curr_irrelevant_expression = substring(curr_note,start_pos_expression_in_note,end_pos_expression_in_note)
                  pos_simclin_in_expression = grep(curr_simclin,curr_irrelevant_expression,ignore.case = TRUE)
                  #is it current simclin? pos_start - pos of current simclin in note
                  if(length(pos_simclin_in_expression)>0)
                    for(i_simclin in 1:length(pos_simclin_in_expression)){
                      if(pos_start>=start_pos_expression_in_note+pos_simclin_in_expression[i_simclin]-1)
                        isSimclinIrrelevant = TRUE
                    }
                }
              }
            }

            # Negations check (if the simclin is relevant)
            if(!isSimclinIrrelevant){
              pattern_pre_negations <- pattern_pre_negations_list[['General']]
              if(length(curr_simclin_categories)>0)
                for (cat_indx in 1:length(curr_simclin_categories)){
                  pattern_pre_negations <- paste(pattern_pre_negations,pattern_pre_negations_list[[curr_simclin_categories[cat_indx]]],sep = "")
                }

              substring_before_simclin =  substring(curr_note,1,pos_end)
              substring_after_simclin =   substring(curr_note,pos_start)

              if(length(pattern_pre_negations)>0){

                #get pattern for pre-negations

                pattern_pre_negations_with_distance <- paste0(pattern_pre_negations,"\\W*",stri_dup("(\\w*)\\W*",as.character(input$distance_between_simclin_and_negation)),"(\\b(",curr_simclin,")(?!\\w))")
                # find all negations near the current simclin
                negations_of_curr_simclin = stri_locate_all(substring_before_simclin, regex = pattern_pre_negations_with_distance, opts_regex=stri_opts_regex(case_insensitive=TRUE))
                pattern_current_pre_negation <- paste0(pattern_pre_negations,"(?=(\\W*",stri_dup("(\\w*)\\W*",as.character(input$distance_between_simclin_and_negation)),"(\\b(",curr_simclin,")(?!\\w))))")
                # if there are negations - check it for exceptions (pseudo and terminations later)
                if(nrow(negations_of_curr_simclin[[1]])>0 & !is.na(negations_of_curr_simclin[[1]][1,'start']))
                  for (i_negation in nrow(negations_of_curr_simclin[[1]]):1){
                    isNegationPseudo = FALSE

                    if(!isSimclinNegated){
                      pos_start_curr_negation = negations_of_curr_simclin[[1]][i_negation,'start']
                      pos_end_curr_negation = negations_of_curr_simclin[[1]][i_negation,'end']

                      post_start_curr_negation_in_note = pos_start_curr_negation
                      post_end_curr_negation_in_note = pos_end_curr_negation

                      if(!is.na(pos_start_curr_negation) & pos_end_curr_negation>=pos_end){

                        curr_simclin_with_negation = substring(substring_before_simclin,pos_start_curr_negation,pos_end_curr_negation)


                        curr_negation = stri_extract_first(curr_simclin_with_negation, regex = pattern_current_pre_negation, opts_regex=stri_opts_regex(case_insensitive=TRUE))
                        curr_negation <- gsub(x = curr_negation,pattern = " ",replacement = "_")

                        if (nrow(df_exceptions)>0 & length(df_exceptions[df_exceptions$Category %in% curr_simclin_categories,'Exception'])>0) {
                          # for every negation - get list of its exceptions
                          exceptions_pattern_str <-df_exceptions[grepl(curr_negation,df_exceptions[df_exceptions$Category %in% curr_simclin_categories,'Exception'],ignore.case = TRUE),'Exception']

                          # find these exceptions near the current simclin
                          exceptions_near_curr_simclin = stri_locate_all(substring_before_simclin, regex = paste("(",paste(exceptions_pattern_str, collapse = '|', sep=""),")", sep=""), opts_regex=stri_opts_regex(case_insensitive=TRUE))

                          # for every exception near simclin
                          if(nrow(exceptions_near_curr_simclin[[1]])>0)
                            for (i_exception in 1:nrow(exceptions_near_curr_simclin[[1]])){
                              pos_start_exception = exceptions_near_curr_simclin[[1]][i_exception,'start']
                              pos_end_exception = exceptions_near_curr_simclin[[1]][i_exception,'end']
                              if(!is.na(pos_start_exception)){
                                curr_exception = substring(substring_before_simclin,pos_start_exception,pos_end_exception)
                                pos_negation_in_exception = grep(curr_negation,curr_exception)
                                #is it current negation?
                                if(length(pos_negation_in_exception)>0)
                                  for(i_negation_in_exception in 1:length(pos_negation_in_exception)){
                                    if(pos_start_curr_negation>=pos_negation_in_exception[i_negation_in_exception]+pos_start_exception-1) {
                                      isNegationPseudo = TRUE
                                    }

                                  }
                              }
                            }
                        }
                        if(!isNegationPseudo) isSimclinNegated = TRUE
                      }
                    } #f(!isSimclinNegated){
                  }#for (i_negation
              } #if(nchar(pattern_pre_negations)>0)

              #if negation was not found - check for post-negations
              if(!isSimclinNegated){

                pattern_post_negations <- pattern_post_negations_list[['General']]
                if(length(curr_simclin_categories)>0)
                  for (cat_indx in 1:length(curr_simclin_categories)){
                    pattern_post_negations <- paste(pattern_post_negations,pattern_post_negations_list[[curr_simclin_categories[cat_indx]]],sep = "")
                  }

                if(length(pattern_post_negations)>0){
                  #get pattern for post-negations
                  pattern_post_negations_with_distance<-paste0("(\\b(",curr_simclin,")(?!\\w))")
                  pattern_post_negations_with_distance <- paste0(pattern_post_negations_with_distance,stri_dup("\\W*(\\w*)",as.character(input$distance_between_simclin_and_negation)),"\\W*",pattern_post_negations)

                  # find all negations near the current simclin
                  negations_of_curr_simclin = stri_locate_all(substring_after_simclin, regex = pattern_post_negations_with_distance, opts_regex=stri_opts_regex(case_insensitive=TRUE))
                  if(nrow(negations_of_curr_simclin[[1]])>0 & !is.na(negations_of_curr_simclin[[1]][1,'start']))
                    for (i_negation in 1:nrow(negations_of_curr_simclin[[1]])){
                      isNegationPseudo = FALSE

                      if(!isSimclinNegated){
                        pos_start_curr_negation = negations_of_curr_simclin[[1]][i_negation,'start']
                        pos_end_curr_negation = negations_of_curr_simclin[[1]][i_negation,'end']

                        post_start_curr_negation_in_note = pos_start_curr_negation + pos_start - 1
                        post_end_curr_negation_in_note = pos_end_curr_negation + pos_start - 1

                        if(!is.na(pos_start_curr_negation)) {
                          curr_simclin_with_negation = substring(substring_after_simclin,pos_start_curr_negation,pos_end_curr_negation)


                          curr_negation = stri_extract_first(curr_simclin_with_negation, regex = pattern_post_negations, opts_regex=stri_opts_regex(case_insensitive=TRUE))
                          df_exceptions_for_current_category <- df_exceptions[df_exceptions$Category %in% curr_simclin_categories,]
                          if (nrow(df_exceptions_for_current_category)>0){
                            # for every negation - get list of its exceptions
                            exceptions_pattern_str <-df_exceptions_for_current_category[grepl(df_exceptions_for_current_category$Exception,curr_negation,ignore.case = TRUE),'Exception']
                            # find these exceptions near the current simclin
                            exceptions_near_curr_simclin = stri_locate_all(substring_after_simclin, regex = paste("(",paste(exceptions_pattern_str, collapse = '|', sep=""),")", sep=""), opts_regex=stri_opts_regex(case_insensitive=TRUE))

                            # for every exception near simclin

                            for (i_exception in 1:nrow(exceptions_near_curr_simclin[[1]])){
                              pos_start_exception = exceptions_near_curr_simclin[[1]][i_exception,'start']
                              pos_end_exception = exceptions_near_curr_simclin[[1]][i_exception,'end']

                              if(!is.na(pos_start_exception)){
                                curr_exception = substring(substring_after_simclin,pos_start_exception,pos_end_exception)
                                pos_negation_in_exception = grep(curr_negation,curr_exception)
                                #is it current negation?
                                for(i_negation_in_exception in 1:length(pos_negation_in_exception)){
                                  if(pos_start_curr_negation>=pos_negation_in_exception[i_negation_in_exception]+pos_start_exception-1)
                                    isNegationPseudo = TRUE
                                }
                              }
                            } #for (i_exception
                          }
                          if(!isNegationPseudo)
                            isSimclinNegated = TRUE
                        }#if(!is.na(pos_start_curr_negation)) {
                      }#if(!isSimclinNegated){
                    }#for (i_negation
                } # check post negations
              } #if(!isSimclinNegated)
            } #if(!isSimclinIrrelevant) then check negations

            if (!isSimclinNegated & !isSimclinIrrelevant) {
              noteOfLabel = TRUE
              curr_simclin <- gsub(x = curr_simclin,pattern = " ",replacement = "_")
              tags_simclins<-rbind(tags_simclins,data.frame("word" = curr_simclin, "start" = pos_start, "end" = pos_end+1))
              if(!(curr_simclin %in% all_simclins_of_note)){
                all_simclins_of_note <- c(all_simclins_of_note,curr_simclin)
                if(length(curr_simclin_categories)>0) {
                  df_positiveLabels[i,paste0(curr_simclin_categories[1],' (simclins)')] <- paste(c(unlist(strsplit(df_positiveLabels[i,paste0(curr_simclin_categories[1],' (simclins)')],split = ", ")),curr_simclin),collapse = ", ")
                  df_positiveLabels[i,paste0(curr_simclin_categories[1],' (# of simclins)')] <- (as.integer(df_positiveLabels[i,paste0(curr_simclin_categories[1],' (# of simclins)')]))+1

                }
              }

            } else {
              if(isSimclinNegated){
                curr_simclin_with_negation<-sub("\\(","\\\\(",curr_simclin_with_negation)
                curr_simclin_with_negation<-sub("\\)","\\\\(",curr_simclin_with_negation)
                curr_note_negations <- append(curr_note_negations,stri_trans_tolower(curr_negation))
                tags_negated_simclins<-rbind(tags_negated_simclins,data.frame("word" = curr_simclin, "start" = post_start_curr_negation_in_note, "end" = post_end_curr_negation_in_note+1))
              }
              else if(isSimclinIrrelevant){
                curr_note_irrelevant_terms<-sub("\\(","\\\\(",curr_note_irrelevant_terms)
                curr_note_irrelevant_terms<-sub("\\)","\\\\(",curr_note_irrelevant_terms)
                curr_note_irrelevant_terms <- append(curr_note_irrelevant_terms,stri_trans_tolower(gsub(" ","_",trimws(curr_irrelevant_expression))))
                tags_irrelevant_simclins<-rbind(tags_irrelevant_simclins,data.frame("word" = curr_simclin, "start" = start_pos_expression_in_note, "end" = end_pos_expression_in_note+1))
              }
            }

          } #if(!is.na(pos_start)&!is.na(pos_end))
          prev_pos_end = pos_end
        }#loop over simclins

      }#loop over pattern list


      #check simclins if they are part of other negated and irrelevant expressions (by coordinates) or other simclins
      if(nrow(tags_simclins)>0) {
        for(tags_indx_simclins in 1:nrow(tags_simclins)){
          if(nrow(tags_negated_simclins)>0)
            for(tags_indx_negated_simclins in 1:nrow(tags_negated_simclins))
              if (as.numeric(tags_simclins[tags_indx_simclins,'start'])>=as.numeric(tags_negated_simclins[tags_indx_negated_simclins,'start'])
                  & as.numeric(tags_simclins[tags_indx_simclins,'end'])<=as.numeric(tags_negated_simclins[tags_indx_negated_simclins,'end'])){
                tags_simclins[tags_indx_simclins,'start']<- 0
                tags_simclins[tags_indx_simclins,'end']<- 0
              }
          if(nrow(tags_irrelevant_simclins)>0)
            for(tags_indx_irrelevant_simclins in 1:nrow(tags_irrelevant_simclins))
              if (as.numeric(tags_simclins[tags_indx_simclins,'start'])>=as.numeric(tags_irrelevant_simclins[tags_indx_irrelevant_simclins,'start'])
                  & as.numeric(tags_simclins[tags_indx_simclins,'end'])<=as.numeric(tags_irrelevant_simclins[tags_indx_irrelevant_simclins,'end'])){
                tags_simclins[tags_indx_simclins,'start']<- 0
                tags_simclins[tags_indx_simclins,'end']<- 0
              }
          #remove simclins which re part of other simclins
          for(tags_indx_simclins2 in 1:nrow(tags_simclins))
            if (rownames(tags_simclins)[tags_indx_simclins]!=rownames(tags_simclins)[tags_indx_simclins2] & as.numeric(tags_simclins[tags_indx_simclins,'start'])>=as.numeric(tags_simclins[tags_indx_simclins2,'start'])
                & as.numeric(tags_simclins[tags_indx_simclins,'end'])<=as.numeric(tags_simclins[tags_indx_simclins2,'end'])){
              tags_simclins[tags_indx_simclins,'start']<- 0
              tags_simclins[tags_indx_simclins,'end']<- 0
            }
        }
        tags_simclins <- tags_simclins[tags_simclins$start>0 & tags_simclins$end>0,]
        all_simclins_of_note <- paste(sort(unlist(lapply(unique(tags_simclins$word),as.character))),collapse = ', ')
      }
      curr_note_negations <- paste(sort(unique(curr_note_negations)),collapse = ', ')
      curr_note_irrelevant_terms <- paste(sort(unique(curr_note_irrelevant_terms)),collapse = ', ')

      #join all tags with their positions
      tags_all <- data.frame(matrix(ncol = 2, nrow = 0))
      colnames(tags_all) <- c("pos","tag")

      if(nrow(tags_simclins)>0){
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_simclins$start),"tag" = "<span class='true-simclin'>"))
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_simclins$end),"tag" = "</span>"))
      }
      if(nrow(tags_negated_simclins)>0){
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_negated_simclins$start),"tag" = "<span class='false-simclin'>"))
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_negated_simclins$end),"tag" = "</span>"))
      }
      if(nrow(tags_irrelevant_simclins)){
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_irrelevant_simclins$start),"tag" = "<span class='false-simclin'>"))
        tags_all <- rbind(tags_all,data.frame("pos" = as.numeric(tags_irrelevant_simclins$end),"tag" = "</span>"))
      }

      #sort tags by their positions in desc order
      tags_all <- tags_all[with(tags_all, order(pos,decreasing = TRUE)),]

      #insert tags
      if(nrow(tags_all)>0)
        for(tag_indx in (1:nrow(tags_all))){
          curr_note <- paste0(substring(curr_note,1,tags_all$pos[tag_indx]-1),tags_all$tag[tag_indx],substring(curr_note,as.numeric(tags_all$pos[tag_indx])))
        }

      #if there is at least one not negated and not irrelevant simclin - the patient's note is labeled as TRUE
      if (nrow(tags_simclins) >0 ) {

        df_irrelevant_positiveLabels = append(df_irrelevant_positiveLabels,NA)
        df_false_positiveLabels = append(df_false_positiveLabels,NA)
        df_positiveLabels[i,'Simclins'] <- all_simclins_of_note

      }
      else {
        if(isSimclinNegated){
          df_false_positiveLabels = append(df_false_positiveLabels,paste(curr_note_negations, collapse = ", "))
          df_irrelevant_positiveLabels = append(df_irrelevant_positiveLabels,NA)
          total_negated_notes<-total_negated_notes+1
        } else if(isSimclinIrrelevant){
          df_false_positiveLabels = append(df_false_positiveLabels,NA)
          df_irrelevant_positiveLabels = append(df_irrelevant_positiveLabels,paste(curr_note_irrelevant_terms, collapse = ", "))
        }

      }
      df_positiveLabels[i,"Note"]<-curr_note
      if (nrow(df_positiveLabels)>1)
        setTxtProgressBar(pb, i)
    }# loop over notes
  }


  df_labeled_data <- read.csv(fileName_all_labeled_data,col.names = c(orignal_source_colnames),stringsAsFactors = FALSE,fileEncoding = "UTF-8")

  df_negatedPosLabels <<- data.table(df_positiveLabels[!is.na(df_false_positiveLabels),orignal_source_colnames])
  df_negatedPosLabels$Label <<- FALSE
  df_labeled_data <- rbind(df_labeled_data,df_negatedPosLabels)
  df_negatedPosLabels$Label <<- NULL
  df_negatedPosLabels$Negation <<- df_false_positiveLabels[!is.na(df_false_positiveLabels)]
  write.csv(df_negatedPosLabels[,c("Note","Negation")], file = paste0(app_dir,"pos_negated_labeled_data.csv"),fileEncoding = "UTF-8")



  df_irrelevantPosLabels <<- data.table(df_positiveLabels[!is.na(df_irrelevant_positiveLabels),orignal_source_colnames])
  df_irrelevantPosLabels$Label <<- FALSE
  df_labeled_data <- rbind(df_labeled_data,df_irrelevantPosLabels)
  df_irrelevantPosLabels$Label <<- NULL
  df_irrelevantPosLabels$Similar_term <<- df_irrelevant_positiveLabels[!is.na(df_irrelevant_positiveLabels)]
  write.csv(df_irrelevantPosLabels[,c("Note","Similar_term")], file = paste0(app_dir,"pos_irrelevant_labeled_data.csv"),fileEncoding = "UTF-8")


  df_positiveLabels <- df_positiveLabels[is.na(df_false_positiveLabels)&is.na(df_irrelevant_positiveLabels),]
  write.csv(df_positiveLabels[ , names(df_positiveLabels) != "NimbleMiner_ID" ] , file = paste0(app_dir,"pos_labeled_data.csv"),fileEncoding = "UTF-8")

  if(nrow(df_positiveLabels)>0)
    df_positiveLabels$Label<- TRUE
  else df_positiveLabels$Label<- logical(0)

  df_labeled_data <- rbind(df_positiveLabels,df_labeled_data, fill = TRUE)
  df_labeled_data<-df_labeled_data[with(df_labeled_data, order(NimbleMiner_ID)), ]
  df_labeled_data$NimbleMiner_ID<-NULL
  df_labeled_data$Note <- gsub("<span class='true-simclin'>", "", df_labeled_data$Note)
  df_labeled_data$Note <- gsub("<span class='false-simclin'>", "", df_labeled_data$Note)
  df_labeled_data$Note <- gsub("</span>", "", df_labeled_data$Note)
  write.csv(df_labeled_data, file = fileName_all_labeled_data, fileEncoding = "UTF-8", na = "")

  total_positive_notes <-nrow(df_positiveLabels)
  total_irrelevant_notes <- nrow(df_irrelevantPosLabels)
  total_negated_notes <- nrow(df_negatedPosLabels)
  total_negative_notes <- total_notes - total_positive_notes - total_negated_notes

  rm(df_false_positiveLabels)
  rm(df_irrelevant_positiveLabels)

  return (list("error_msg" = "","total_notes" = total_notes, "total_positive_notes" = total_positive_notes,"total_irrelevant_notes" = total_irrelevant_notes,"total_negated_notes" = total_negated_notes,"total_negative_notes"=total_negative_notes))
}
