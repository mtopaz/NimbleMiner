library(stringi)
library(tm)
library(wordVectors)
library(rword2vec)

addNewSimclin <- function(new_simclin_str,simclins, category = NULL){

  # trim the new simclin
  new_simclin_str = enc2utf8(new_simclin_str)
  new_simclin_str = gsub("_", " ", trimws(new_simclin_str))
  new_simclin_str = tm::removePunctuation(new_simclin_str,preserve_intra_word_contractions = FALSE,preserve_intra_word_dashes = FALSE,ucp = TRUE)
  new_simclin_str = gsub("[[:space:]]", "_", trimws(new_simclin_str))
  new_simclin_str=stringi::stri_trans_tolower(new_simclin_str)
  print(paste0("Add new simclin: ",new_simclin_str))

  #add button 'Examples'
  examples_str <- paste0("<button type='button' class='btn btn-secondary load' onclick='Shiny.onInputChange(\"lastClickId\",this.id);' id='next_examples_for_",new_simclin_str,"#0'><i class='icon-left'></i>Examples</button>")
  #add simclin to data frame
  newSimclin_row=data.frame(Simclins = new_simclin_str, Category = category, Processed = FALSE, Examples = examples_str,stringsAsFactors=FALSE)
  if (is.null(simclins))
    simclins <- newSimclin_row
  else simclins<-rbind(simclins,newSimclin_row)
  return(simclins)

}
#############################################################################################################
# Function readFileByChunks - read chars from the file by chunks
# The function is used to set pointer in large text
#############################################################################################################
readFileByChunks <-function(in_file, nchar,length_of_text_chunk = 5e7){
  while (nchar>length_of_text_chunk){
    readChar(in_file,length_of_text_chunk)
    nchar <- nchar - length_of_text_chunk
  }
  if(nchar>1)
    readChar(in_file,nchar)
}
#############################################################################################################
# Function setCursorInTextFile - set file pointer to the new_pos position
# The function is used for preprocessing of large texts
#############################################################################################################
setCursorInTextFile<-function (in_file, fileName, curr_pos, new_pos, length_of_text_chunk = 5e7){

  if (curr_pos == new_pos)
    return()

  if(new_pos<curr_pos){
    close(in_file)
    in_file = file(fileName, "r")
    open(in_file)
    curr_pos <- 1
  }

  if (new_pos>1){
    if (new_pos>curr_pos)
      readFileByChunks(in_file,new_pos-curr_pos,length_of_text_chunk)
    else readFileByChunks(in_file,new_pos,length_of_text_chunk)
  }
}
#############################################################################################################
# Function getExamples - returns string with 10 examples of appearance "pattern" string in "source_txt" text.
# The search of matches begins from the "last_pos" position in source_txt in forward direction (direction=1) or reverse direction (direction=0)
#############################################################################################################
getExamples <- function(direction,pattern, last_pos,control_id,length_of_text_chunk=2e7){

  # txt file for examples
  if (n_grams==1)
    fileName <- paste0(app_dir,"train.txt")
  else if(n_grams==2)
    fileName <- paste0(app_dir,"train2.txt")
  else if(n_grams==4)
    fileName <- paste0(app_dir,"train4.txt")

  example_str <- NimbleMiner::getExamples(pattern, fileName, control_id, last_pos,direction,length_of_text_chunk)

  return (example_str)
}

######################
# Function getExamples - returns string with 10 examples of appearance "pattern" string in "source_txt" text.
# The search of matches begins from the "last_pos" position in source_txt in forward direction (direction=1) or reverse direction (direction=0)
#####################

#' Getting HTML code with 10 examples of the simclin in the source text, Prev and Next buttons for paging among examples
#'
#'
#' @param pattern character string: A simclin, for which the examples should be found.
#' @param source_filename character string: Name of the file where examples are sought (should be specified this parameter or the source_txt)
#' @param control_id character string: ID if parent
#' @param last_pos numeric: The search of matches begins from the last_pos position in source_txt in forward direction (direction=1) or reverse direction (direction=0)
#' @param direction numeric: The search of matches in forward direction (direction=1) or reverse direction (direction=0)
#' @return The output will be updated simclins data frame.
#'
#' @examples
#' df_simclins<<-NimbleMiner::addNewSimclin('insulin',df_simclins,'Diabetes')
#'

getExamples <- function(pattern,source_filename, control_id, last_pos = 0,direction = 1,length_of_text_chunk=2e7){

  if (file.exists(source_filename)) {
    file_size = file.info(source_filename)$size
    in.file = file(source_filename, "r")
    open(in.file,"r")
  } else {
    return (paste0("<div class='example-text'> The file ",source_filename,"  for examples search is not found!</div>"))
  }

  #construct the pattern
  pattern_str <- paste0("\\b(",pattern,")(?!\\w)")

  exmpl_number<-0
  examples_str<-""
  offset_pos <-0
  text_start_pos<-1
  text_end_pos <-file_size

  #cut the source text in needed direction
  if (direction==1)
    text_start_pos <- last_pos
  else
    text_end_pos = last_pos

  length_of_search_text <- text_end_pos - text_start_pos

  if (length_of_search_text>length_of_text_chunk)
    step_count<-ceiling(length_of_search_text / length_of_text_chunk) #TODO: words divided by boundaries will not be found
  else step_count<-1

  if (direction==1){
    step_boundary_start  <- 1
    step_boundary_finish <- step_count
  } else {
    step_boundary_start <- step_count
    step_boundary_finish <- 1
  }

  cursor_in_file <- text_start_pos
  #set cursor to begin of text in file
  setCursorInTextFile(in.file, fileName, 0, cursor_in_file)

  for (step in step_boundary_start:step_boundary_finish){

    if (step==step_boundary_finish){
      if (direction==1){
        next_part_of_source_txt = readChar(in.file,length_of_text_chunk)
        cursor_in_file <- cursor_in_file + length_of_text_chunk
      }
      else {
        setCursorInTextFile(in.file, fileName, cursor_in_file, 1)
        next_part_of_source_txt = readChar(in.file,cursor_in_file)
        cursor_in_file <-1
      }
    }
    else {
      if (direction==1){
        next_part_of_source_txt = readChar(in.file,length_of_text_chunk)
        cursor_in_file <- cursor_in_file + length_of_text_chunk+1
      }
      else {
        setCursorInTextFile(in.file, fileName, cursor_in_file, length_of_text_chunk*(step-1)+1)
        next_part_of_source_txt = readChar(in.file,length_of_text_chunk)
        cursor_in_file <- length_of_text_chunk*(step-1)
      }
    }

    #search the matches
    pos = stri_locate_all(next_part_of_source_txt, regex = pattern_str, opts_regex=stri_opts_regex(case_insensitive=TRUE))

    if (direction==1) {
      for (j in 1:nrow(pos[[1]])){
        pos_start = pos[[1]][j,'start']
        pos_end   = pos[[1]][j,'end']
        if(!is.na(pos_start)){
          width_phrase =  pos_end - pos_start+1
          pos_before_start <- pos_start - const_side_chars
          boundary_addition <- ""

          pos_after_end <- pos_start + const_side_chars
          if (pos_after_end>nchar(next_part_of_source_txt)) pos_after_end = nchar(next_part_of_source_txt)

          new_example_str <- paste0("<div class='example-text'>...",substring(next_part_of_source_txt, pos_before_start-10, pos_before_start-1),
                                    "<span class='window-text'>",paste0(boundary_addition,substring(next_part_of_source_txt, pos_before_start, pos_after_end)),"</span>",
                                    substring(next_part_of_source_txt, pos_after_end+1, pos_after_end+10),"...</div>")

          new_example_str <- gsub(pattern, paste0("<b>",pattern,"</b>"), new_example_str)

          if (length(examples_str)>1) examples_str <-paste0(examples_str,'<br>')
          examples_str <- paste0(examples_str,new_example_str)
          exmpl_number<-exmpl_number+1

          if (exmpl_number==10) break
        }
      }
    } else {
      for (j in nrow(pos[[1]]):1){

        pos_start = pos[[1]][j,'start']
        pos_end   = pos[[1]][j,'end']
        if(!is.na(pos_start)){
          width_phrase =  pos_end - pos_start+1

          pos_before_start <- pos_start - const_side_chars
          if (pos_before_start<1) pos_before_start = 1

          pos_after_end <- pos_start + const_side_chars
          boundary_addition <- ""
          new_example_str <- paste0("<div class='example-text'>...",substring(next_part_of_source_txt, pos_before_start-10, pos_before_start-1),
                                    "<span class='window-text'>",paste0(substring(next_part_of_source_txt, pos_before_start, pos_after_end),boundary_addition),"</span>",
                                    substring(next_part_of_source_txt, pos_after_end+1, pos_after_end+10),"...</div>")

          new_example_str <- gsub(pattern, paste0("<b>",pattern,"</b>"), new_example_str)

          if (length(examples_str)>1) examples_str <-paste0('<br>',examples_str)
          examples_str <- paste0(new_example_str,examples_str)
          exmpl_number<-exmpl_number+1
          if (exmpl_number==10) break
        }
      }
    }
    if (exmpl_number==10) break
  } # for step

  #add prev and next buttons
  offset_pos <- length_of_text_chunk*(step-1)
  absolute_last_pos_match = offset_pos + pos_start
  if(examples_str!=''){
    if (direction==1){   #next

      if (last_pos>0)
        examples_str<-paste0(examples_str," <button type='button' class='btn btn-secondary load' onclick='Shiny.onInputChange(\"",control_id,"\",this.id);' id='prev_examples_for_",pattern,"#",
                             as.character(last_pos),"'><i class='icon-left'></i>Prev</button>")
      if (j<nrow(pos[[1]]) || step<step_count) #ToDO: next steps could not contain examples
        examples_str<-paste0(examples_str," <button type='button' class='btn btn-secondary load' onclick='Shiny.onInputChange(\"",control_id,"\",this.id);' id='next_examples_for_",pattern,"#",
                             as.character(last_pos+absolute_last_pos_match+width_phrase),"'><i class='icon-right'></i>Next</button>")
    } else {  #prev
      if (j>1 || step>1)  #ToDO: prev steps could not contain examples
        examples_str<-paste0(examples_str," <button type='button' class='btn btn-secondary load' onclick='Shiny.onInputChange(\"",control_id,"\",this.id);' id='prev_examples_for_",pattern,"#",
                             as.character(absolute_last_pos_match),"'><i class='icon-left'></i>Prev</button>")
      examples_str<-paste0(examples_str," <button type='button' class='btn btn-secondary load' onclick='Shiny.onInputChange(\"",control_id,"\",this.id);' id='next_examples_for_",pattern,"#",
                           as.character(last_pos),"'><i class='icon-left'></i>Next</button>")
    }

  } else {
    examples_str <- "There are no examples for this term in the text."
  }

  close(in.file)

  return  (examples_str)
}

######################
# Function closestByLevenstein - returns vector of of elements (indeces) of argument vector_of_words, which are close (by Levenstein maximum distance <= argument max) to argument word
######################
closestByLevenstein <- function(word,vector_of_words,max,min_word_length = 4){
  if (nchar(word)<min_word_length)
    return (character(0))
  else {
    distance_matrix <- adist(word,vector_of_words,ignore.case = TRUE)
    return (distance_matrix<=max)
  }
}

findNewSimilarTerms<-function(df_new_simclins,category_str,models_files, similar_terms_count = 50, load_model_to_memory = TRUE ){

  const_multipl_similar_terms <- 10

  if (length(models_files)==0){
    showModal(modalDialog(title = "Error message",  "No any model is found! Please, build at least the base model before.",easyClose = TRUE))
    return()
  }

  # for each new simclin get closest words

  df_similar_terms_as_result <- data.frame()
  df_cashed_similar_terms <- data.frame()

    for(model_indx in 1:length(models_files)){

      print(paste0('Find Similar terms for model ',models_files[model_indx],'...'))
      print('Find Similar terms for:')

      if(grepl("\\.rds$",models_files[[model_indx]]))
        model_type <- 'GloVe'
      else if(grepl("\\.bin$",models_files[[model_indx]]))
        model_type <- 'word2vec'

      if(load_model_to_memory & is.null(models[[model_indx]])){
        print(paste0('Reading a word2vec binary file ',models_files[model_indx]))
        if( model_type == 'word2vec')
          models[[model_indx]] <<- read.vectors(paste0(app_dir,models_files[model_indx]))
        else if( model_type == 'GloVe')
          models[[model_indx]] <<- readRDS(paste0(app_dir,models_files[model_indx]))
      }

      for(i in 1:nrow(df_new_simclins)) {
        start_time <- Sys.time()

        row <- df_new_simclins[i,]
        simclin_str <- as.character(row$Simclins)
        simclin_str <- gsub(" ","_",simclin_str)

        print(paste0('Find Similar terms for: ',simclin_str))

        start_time_search = Sys.time()

        # get num closest words from word2vec model
        if(model_type == 'word2vec') {
          # load model into memory (package wordVectors)
          if(load_model_to_memory){
            df_new_similar_terms = closest_to(models[[model_indx]],simclin_str,similar_terms_count*const_multipl_similar_terms+1,FALSE) #wordVectors +1 - because it return the simclin with distance 1 too
            #remove words with 0 distance
            df_new_similar_terms<-df_new_similar_terms[!is.nan(df_new_similar_terms[,2]),]

          }
          # dont load model into memory (package rword2vec)
          else {
            df_new_similar_terms = rword2vec::distance(file_name = models_files[model_indx],search_word = simclin_str,num = similar_terms_count*const_multipl_similar_terms)
            #remove words with 0 distance
            df_new_similar_terms<-df_new_similar_terms[!is.nan(df_new_similar_terms[,2]) & df_new_similar_terms[,2]!=-1,]

          }

        }
        # get num closest words from GloVe model
        else if(model_type == 'GloVe') {
          if(load_model_to_memory){
            if(simclin_str %in% rownames(models[[model_indx]]))
              cos_sim = sim2(x = models[[model_indx]], y =  models[[model_indx]][simclin_str, , drop = FALSE], method = "cosine", norm = "l2")
            else cos_sim = NULL
          }
          else {
            word_vectors <- readRDS(paste0(app_dir,models_files[model_indx]))
            if(simclin_str %in% rownames(word_vectors))
              cos_sim = sim2(x = word_vectors, y =  word_vectors[simclin_str, , drop = FALSE], method = "cosine", norm = "l2")
            else cos_sim = NULL
            rm(word_vectors)
          }
          if (!is.null(cos_sim)){
            df_new_similar_terms <- head(sort(cos_sim[,1], decreasing = TRUE), similar_terms_count*const_multipl_similar_terms+1)
            df_new_similar_terms <- as.data.frame(df_new_similar_terms)
            df_new_similar_terms$word <- rownames(df_new_similar_terms)
            rownames(df_new_similar_terms) <- 1:nrow(df_new_similar_terms)
            df_new_similar_terms$dist <- df_new_similar_terms[,1]
            df_new_similar_terms[,1] <- NULL
            df_new_similar_terms<-df_new_similar_terms[!is.nan(df_new_similar_terms[,2]) & df_new_similar_terms[,2]!=-1,]
          }  else df_new_similar_terms = data.frame()
        }

        print(paste0("Search in model ",models_files[model_indx],": ",as.character(round((difftime(Sys.time(),start_time_search,units = "secs")),2))))


        #if there are new similar terms
        if (nrow(df_new_similar_terms)>0){

          start_time_process = Sys.time()
          df_new_similar_terms$Model <- models_files[model_indx]
          df_new_similar_terms$By_simclins <- simclin_str
          colnames(df_new_similar_terms)[2]<-"dist"


          factor_cols <- sapply(df_new_similar_terms, is.factor)
          df_new_similar_terms[factor_cols] <- lapply(df_new_similar_terms[factor_cols], as.character)

          # Ignore empty words, unicode padding and unicode file header
          df_new_similar_terms <- df_new_similar_terms[!is.na(df_new_similar_terms$word) & df_new_similar_terms$word!="" & df_new_similar_terms$word!="\376" & df_new_similar_terms$word!="\377",]

          if(model_indx==1){
            df_similar_terms_as_result <- rbind(df_similar_terms_as_result,head(df_new_similar_terms,similar_terms_count))
            df_cashed_similar_terms <- rbind(df_cashed_similar_terms,tail(df_new_similar_terms,nrow(df_new_similar_terms)-similar_terms_count))
          } else   df_cashed_similar_terms <- rbind(df_cashed_similar_terms,df_new_similar_terms)

          # check for close words by Levenshtein distance
          closest_by_lv <- closestByLevenstein(simclin_str,df_cashed_similar_terms[,'word'], max = 2)

          if(length(closest_by_lv)>0){
            df_similar_terms_closest_by_lv <- df_cashed_similar_terms[closest_by_lv,]
            df_cashed_similar_terms <- df_cashed_similar_terms[!closest_by_lv,]
            df_similar_terms_as_result <-rbind(df_similar_terms_as_result,df_similar_terms_closest_by_lv)
          }
          print(paste0("Processing of search results: ",as.character(round((difftime(Sys.time(),start_time_process,units = "secs")),2))))
        } else {
          print(paste0("There are no any similar terms for '",simclin_str,"' in model ",models_files[model_indx],"."))
        }
        # mark this simclin as processed
        df_simclins[df_simclins$Simclins==simclin_str &  df_simclins$Category==category_str,'Processed'] <<-TRUE



      }#loop by simclins


    }#loop by models

    #find duplicated terms among models

    start_time_final_process = Sys.time()

    if(nrow(df_similar_terms_as_result)>0){
      df_similar_terms_as_result[,2]<-round(as.numeric(df_similar_terms_as_result[,2]),2)
    }
    if (nrow(df_cashed_similar_terms)>0) {
      df_cashed_similar_terms<-df_cashed_similar_terms[!duplicated(df_cashed_similar_terms[,c('word','Model')]),]
      df_cashed_similar_terms[,2]<-round(as.numeric(df_cashed_similar_terms[,2]),2)
      df_cashed_similar_terms<-aggregate(. ~ word,data = df_cashed_similar_terms,toString)
      df_similar_terms_duplicated <- df_cashed_similar_terms[grepl(',',df_cashed_similar_terms$Model),]
      if(nrow(df_similar_terms_duplicated)>0)
        df_similar_terms_as_result <-rbind(df_similar_terms_as_result,df_similar_terms_duplicated)
      print(paste0(nrow(df_similar_terms_duplicated),' repeats of same terms in several models were found.'))
      rm(df_similar_terms_duplicated)
    }


    print(paste0("Final processing of search results: ",as.character(round((difftime(Sys.time(),start_time_final_process,units = "secs")),2))))
    process_duration <- as.character(round((difftime(Sys.time(),start_time,units = "mins")),2))
    print(paste0("System search similar terms for simclins: ", process_duration))

    rm(df_new_similar_terms)
    rm(df_cashed_similar_terms)
    rm(df_new_simclins)

    return (df_similar_terms_as_result)

}
