library(testthat)
test_check("wordVectors")
